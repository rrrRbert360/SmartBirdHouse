Notes on the Laser engraving files:

1. Don't focus the laser on the wood; use a bit out-of-focus;
2. Use vector files(e.g. dxf) to engrave with laser on wood; this is much faster and cheaper than bitmap files(e.g. jpg);
3. When you use the single birdhouse tattoo file, you must turn the wooden plank to carve both side panels;
4. It is advised to use make two birdhouses and use two different files; one for one plank with 2 Left panels and the other for 2 Right-panels;
5. Credits for the Tattoo design art-work to Iris Heerekop.
6. Share your improvements! 